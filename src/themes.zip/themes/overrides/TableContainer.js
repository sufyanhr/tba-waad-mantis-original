// ==============================|| OVERRIDES - TABLE CONTAINER ||============================== //

export default function TableContainer() {
  return {
    MuiTableContainer: {
      styleOverrides: {
        root: {
          borderRadius: 0
        }
      }
    }
  };
}
